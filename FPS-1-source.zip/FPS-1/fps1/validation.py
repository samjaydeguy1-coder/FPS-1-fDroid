from __future__ import annotations

import numpy as np
import pandas as pd

from .model import predict_components, blend_components, market_probabilities


def multiclass_logloss(y, p):
    y = np.asarray(y, dtype=int)
    p = np.asarray(p, dtype=float)
    return float(-np.mean([
        np.log(max(float(p[i, yi]), 1e-12))
        for i, yi in enumerate(y)
    ]))


def multiclass_brier(y, p, classes=3):
    y = np.asarray(y, dtype=int)
    p = np.asarray(p, dtype=float)
    oh = np.eye(classes)[y]
    return float(np.mean(np.sum((p - oh) ** 2, axis=1)))


def evaluate_walk_forward(
    df,
    weights,
    max_goals=10,
    min_train=80,
    decay_days=730,
    recent_n=8,
    elo_k=20,
    elo_home_adv=60,
    step=1
):
    """
    Chronological expanding-window evaluation.

    The ensemble and baseline both use only the historical
    matches available before each test match.

    Baseline probabilities use Laplace smoothing.
    """
    all_rows = []

    finished = df[df.status == "finished"]

    for league, group in finished.groupby("league"):
        g = group.sort_values("date").reset_index(drop=True)

        for i in range(min_train, len(g), step):
            row = g.iloc[i]
            hist = g.iloc[:i]

            try:
                # Historical outcomes: 0=Home, 1=Draw, 2=Away
                hist_actual = np.where(
                    hist.home_goals > hist.away_goals,
                    0,
                    np.where(
                        hist.home_goals == hist.away_goals,
                        1,
                        2
                    )
                )

                # Leakage-free historical-frequency baseline.
                # Add one observation to each outcome category.
                counts = np.bincount(hist_actual, minlength=3)
                baseline_p = (counts + 1.0) / (counts.sum() + 3.0)

                # FPS-1 ensemble prediction.
                comp = predict_components(
                    hist,
                    row.home_team,
                    row.away_team,
                    row.date,
                    max_goals,
                    decay_days,
                    recent_n,
                    elo_k,
                    elo_home_adv
                )

                mat = blend_components(comp, weights)
                probs = market_probabilities(mat)["1X2"]

                p = [
                    probs["home"],
                    probs["draw"],
                    probs["away"]
                ]

                actual = (
                    0 if row.home_goals > row.away_goals
                    else 1 if row.home_goals == row.away_goals
                    else 2
                )

                all_rows.append({
                    "league": league,
                    "date": row.date,
                    "home_team": row.home_team,
                    "away_team": row.away_team,
                    "actual": actual,

                    "p_home": p[0],
                    "p_draw": p[1],
                    "p_away": p[2],

                    "baseline_p_home": baseline_p[0],
                    "baseline_p_draw": baseline_p[1],
                    "baseline_p_away": baseline_p[2],

                    "logloss": -np.log(max(p[actual], 1e-12)),
                    "brier": sum(
                        (np.eye(3)[actual] - np.array(p)) ** 2
                    ),

                    "baseline_logloss": -np.log(
                        max(baseline_p[actual], 1e-12)
                    ),
                    "baseline_brier": sum(
                        (np.eye(3)[actual] - baseline_p) ** 2
                    )
                })

            except Exception:
                continue

    out = pd.DataFrame(all_rows)

    if out.empty:
        return out, {}

    y = out["actual"].to_numpy(dtype=int)

    p = out[
        ["p_home", "p_draw", "p_away"]
    ].to_numpy(dtype=float)

    bp = out[
        [
            "baseline_p_home",
            "baseline_p_draw",
            "baseline_p_away"
        ]
    ].to_numpy(dtype=float)

    metrics = {
        "matches": int(len(out)),

        "log_loss": multiclass_logloss(y, p),
        "brier_score": multiclass_brier(y, p),

        "accuracy": float(
            (p.argmax(axis=1) == y).mean()
        ),

        "baseline_log_loss": multiclass_logloss(y, bp),
        "baseline_brier_score": multiclass_brier(y, bp),

        "baseline_accuracy": float(
            (bp.argmax(axis=1) == y).mean()
        )
    }

    return out, metrics


def calibration_table(predictions, bins=10):
    if predictions.empty:
        return pd.DataFrame()

    rows = []

    for label, col, actual_code in [
        ("Home", "p_home", 0),
        ("Draw", "p_draw", 1),
        ("Away", "p_away", 2)
    ]:
        d = predictions[[col, "actual"]].copy()

        d["bin"] = pd.cut(
            d[col],
            bins=np.linspace(0, 1, bins + 1),
            include_lowest=True
        )

        for interval, g in d.groupby("bin", observed=True):
            if len(g):
                rows.append({
                    "outcome": label,
                    "probability_bin": str(interval),
                    "mean_predicted": g[col].mean(),
                    "observed_frequency": (
                        g.actual == actual_code
                    ).mean(),
                    "count": len(g)
                })

    return pd.DataFrame(rows)
